const button = document.querySelector('#btn');
const list = document.querySelector('#list');

var row = 0;

button.addEventListener('click',function(){

let item = document.querySelector("#todo").value;
  
    let text = document.createTextNode(item);
    let listItem = document.createElement('li');
    let listSpan = document.createElement('span');
    listSpan.appendChild(text);
    list.appendChild(listItem);
    listItem.appendChild(listSpan);
    listItem.setAttribute("id","myId"+row);
    listItem.setAttribute("class","clear");
    document.forms.myForm.reset();
   

    // Create Remove Button
    var removeTask = document.createElement('input');
  
    function setAttributes(el, options) {
       Object.keys(options).forEach(function(attr) {
         el.setAttribute(attr, options[attr]);
      })
    }
    setAttributes(removeTask, {type: "button", value: "X", id: "removeButton", title: "Remove", onClick: "deleterow("+ row +");",});
    listItem.appendChild(removeTask);

    row++;
    store();  // Update store list

})


// Remove list
function deleterow(ID)
{
    document.getElementById('myId'+ID).remove();
    store();   // Update store list 
}

// Store list
function store() {
    window.localStorage.myItems = list.innerHTML;
}
  
// Get Store Value
function getValues() {
     var storedValues = window.localStorage.myItems;
     list.innerHTML = storedValues;
}
getValues();



